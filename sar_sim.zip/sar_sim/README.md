# SAR multi-drone simulation

Multiple finder drones search a 2 km x 2 km area (20 m grid, origin = mothership) for victims with **no GPS**. Each drone:

- Navigates by dead reckoning. Its position error grows as it flies and resets near the mothership or near ESP32 UWB anchors it drops along the way.
- Senses with a thermal camera (with false alarms), a BLE/Wi-Fi phone RSSI scanner and an RGB camera for close-range confirmation.
- Sends detection packets in the team data contract: `{source_id, t, type, x, y, err, ...}`.

A shared **belief map** (the probability that a victim is in each cell) combines all the detections. The planner sends drones to high-value areas, sends one low to confirm a candidate, and returns drones to the mothership to recharge.

## Setup (Windows)

```
cd "C:\Users\gavin\Desktop\code metal\sar_sim"
py -m pip install numpy matplotlib
py run_sim.py
```

## Run options

| Command | What it does |
|---|---|
| `py run_sim.py` | Live 2D view (3 drones, 3 victims) |
| `py run_sim.py --drones 5 --victims 4 --seed 3` | Different scenario |
| `py run_sim.py --hotspot 400,300,250` | Last-known-position prior (x, y, sigma in m) |
| `py run_sim.py --planner lawnmower` | Baseline strip sweep, for comparison |
| `py run_sim.py --compare --runs 10` | Batch stats: belief planner vs lawnmower |
| `py run_sim.py --log detections.jsonl` | Save every detection packet (for the code team) |
| `py run_sim.py --backend pybullet` | 3D physics view (Crazyflie models) |

Keys in the live view: **space** pause · **+/-** speed · **t** show/hide true victim positions · **c** switch between probability and coverage · **q** quit.

## 3D backend (optional)

```
py -m pip install pybullet gymnasium scipy transforms3d pillow
py -m pip install --no-deps git+https://github.com/utiasDSL/gym-pybullet-drones
py run_sim.py --backend pybullet
```

The 2 km area is scaled into a 20 m arena. On Windows, if `pybullet` fails to build, use Python 3.10–3.11 or `conda install -c conda-forge pybullet`.

## Code map

| File | Owner / purpose |
|---|---|
| `sar_sim/drone.py` | `Drone` interface: `takeoff / goto / land / get_pose / get_detections`. `SimDrone` (2D). Add `CrazyflieDrone` / `TinyhawkDrone` here later. |
| `sar_sim/backends/pybullet_backend.py` | 3D physics drones (same interface) |
| `sar_sim/sensors.py` | Thermal, BLE RSSI and RGB-CV models, which output data-contract packets (Mabelle / Mohammed) |
| `sar_sim/belief.py` | Layered grid: probability, coverage, last seen, thermal, RF (Aurora) |
| `sar_sim/planner.py` | Task allocation. Swap in MCTS / A* by replacing `_pick_search_target` (Aurora) |
| `sar_sim/sim.py` | Main loop, UWB anchors and fixes, data association |
| `sar_sim/config.py` | Every tunable number (speeds, sensor ranges, battery, drift) |
| `sar_sim/viz.py` | Live view |

## Sample results (headless, 3 drones, 3 victims)

| Scenario | Planner | All victims found | Median first find | Median time to find all |
|---|---|---|---|---|
| Uniform prior, 10 runs | Belief | 90% of runs | 258 s | 1251 s |
| Uniform prior, 10 runs | Lawnmower | 80% of runs | 527 s | 1454 s |
| Last-known-position prior, 8 runs | Belief | 100% of runs | 54 s | 748 s |
| Last-known-position prior, 8 runs | Lawnmower | 62% of runs | 252 s | 2219 s |
