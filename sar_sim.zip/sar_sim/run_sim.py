"""Multi-drone search-and-rescue simulation.

Examples
  python run_sim.py                         # live 2D view, 3 drones, 3 victims
  python run_sim.py --drones 5 --victims 4 --seed 3
  python run_sim.py --hotspot 400,300,250   # last-known-position prior
  python run_sim.py --planner lawnmower     # baseline sweep for comparison
  python run_sim.py --headless --runs 20    # batch stats, no window
  python run_sim.py --compare --runs 20     # belief planner vs lawnmower
  python run_sim.py --backend pybullet      # 3D physics view (Crazyflie models)
  python run_sim.py --log detections.jsonl  # write every detection packet
"""
import argparse
import statistics as st

from sar_sim.config import SimConfig
from sar_sim.sim import Simulation
from sar_sim.planner import Planner, LawnmowerPlanner


def make_sim(args, seed, planner="belief", log=None):
    cfg = SimConfig(seed=seed, n_drones=args.drones, n_victims=args.victims,
                    max_time_s=args.max_time)
    if args.hotspot:
        cfg.prior_hotspot = tuple(float(v) for v in args.hotspot.split(","))
    drones = None
    if args.backend == "pybullet":
        from sar_sim.backends.pybullet_backend import PyBulletFleet
        fleet = PyBulletFleet(cfg, gui=not args.headless)
        drones = fleet.drones
    sim = Simulation(cfg, drones=drones, log_path=log)
    if args.backend == "pybullet":
        fleet.attach(sim)
    if planner == "lawnmower":
        sim.planner = LawnmowerPlanner(cfg, sim.belief)
    return sim


def batch(args, planner):
    times, found, first = [], [], []
    for k in range(args.runs):
        sim = make_sim(args, args.seed + k, planner)
        while not sim.done:
            sim.step()
        sm = sim.summary()
        found.append(sm["found"] / sm["total"])
        if sm["find_times"]:
            first.append(min(sm["find_times"]))
        times.append(sim.t if sm["found"] == sm["total"] else float("nan"))
        print(f"  [{planner}] seed {args.seed + k}: {sm}")
    done = [t for t in times if t == t]
    return dict(planner=planner, runs=args.runs,
                all_found_pct=100 * len(done) / args.runs,
                mean_found_pct=100 * st.mean(found),
                median_time_s=st.median(done) if done else None,
                median_first_s=st.median(first) if first else None)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--drones", type=int, default=3)
    ap.add_argument("--victims", type=int, default=3)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--max-time", type=float, default=3600)
    ap.add_argument("--hotspot", help="x,y,sigma  last-known-position prior (m)")
    ap.add_argument("--planner", choices=["belief", "lawnmower"], default="belief")
    ap.add_argument("--backend", choices=["2d", "pybullet"], default="2d")
    ap.add_argument("--speed", type=int, default=5, help="sim steps per frame")
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--runs", type=int, default=1)
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--log", help="write detection packets (JSON lines) here")
    ap.add_argument("--save", help="save animation to .gif/.mp4 instead of showing")
    ap.add_argument("--hide-truth", action="store_true")
    args = ap.parse_args()

    if args.compare:
        res = [batch(args, "belief"), batch(args, "lawnmower")]
        print("\nRESULTS")
        for r in res:
            print(f"  {r['planner']:<10} all victims found in {r['all_found_pct']:.0f}% of runs | "
                  f"avg {r['mean_found_pct']:.0f}% found | median first find: {r['median_first_s']} s | "
              f"median time to find all: {r['median_time_s']} s")
        return
    if args.headless and args.backend == "2d":
        r = batch(args, args.planner)
        print(r)
        return

    sim = make_sim(args, args.seed, args.planner, log=args.log)
    if args.backend == "pybullet" and args.headless:
        while not sim.done:
            sim.step()
        print(sim.summary())
        return
    from sar_sim.viz import LiveView
    view = LiveView(sim, steps_per_frame=args.speed, show_truth=not args.hide_truth)
    view.run(save_path=args.save, frames=(600 if args.save else None))
    sim.close()


if __name__ == "__main__":
    main()
