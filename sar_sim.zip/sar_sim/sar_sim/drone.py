"""Drone interface + 2D simulated drone.

Planning / mapping code ONLY talks to the `Drone` interface. Swap SimDrone for
PyBulletDrone (3D sim), CrazyflieDrone (cflib) or TinyhawkDrone (MSP) without
touching the planner.
"""
from abc import ABC, abstractmethod
import numpy as np


class Drone(ABC):
    drone_id: str

    @abstractmethod
    def takeoff(self, height_m: float): ...

    @abstractmethod
    def goto(self, x: float, y: float, z: float):
        """Fly to (x, y, z) in the shared map frame (meters from the mothership)."""

    @abstractmethod
    def land(self): ...

    @abstractmethod
    def get_pose(self):
        """-> (x, y, z, yaw, err)  estimated pose + 1-sigma position error (m)."""

    @abstractmethod
    def get_detections(self) -> list:
        """-> list of detection packets (data-contract dicts) since last call."""

    # Optional, used by simulators
    def step(self, dt: float, t: float): ...


class SimDrone(Drone):
    """Kinematic point-mass drone with GPS-denied dead-reckoning drift."""

    def __init__(self, drone_id, cfg, rng, start_xy=(0.0, 0.0)):
        self.drone_id, self.cfg, self.rng = drone_id, cfg, rng
        self.true_pos = np.array([start_xy[0], start_xy[1], 0.0])
        self.bias = np.zeros(2)          # est - true (horizontal)
        self.err = 0.5
        self._drift_dir = rng.uniform(0, 2 * np.pi)
        self.target = None               # in estimated frame
        self.state = "landed"            # landed | flying | charging
        self.task = "idle"               # idle | search | confirm | return
        self.battery_s = cfg.battery_s
        self.charge_left = 0.0
        self.anchors_left = cfg.anchors_per_drone
        self.trail = []
        self._pending = []
        self.yaw = 0.0
        self.sensors = None              # injected by Simulation

    # ---- interface ----
    @property
    def est_pos(self):
        return np.array([self.true_pos[0] + self.bias[0], self.true_pos[1] + self.bias[1], self.true_pos[2]])

    def takeoff(self, height_m):
        if self.state == "landed":
            self.state = "flying"
            e = self.est_pos
            self.target = np.array([e[0], e[1], height_m])

    def goto(self, x, y, z):
        if self.state == "landed":
            self.takeoff(z)
        self.target = np.array([x, y, z], dtype=float)

    def land(self):
        e = self.est_pos
        self.target = np.array([e[0], e[1], 0.0])

    def get_pose(self):
        e = self.est_pos
        return (float(e[0]), float(e[1]), float(e[2]), float(self.yaw), float(self.err))

    def get_detections(self):
        out, self._pending = self._pending, []
        return out

    # ---- simulation ----
    land_eps = 0.05

    def _move(self, dt):
        """Kinematic motion. Steers toward the target in the *estimated* frame, so true
        motion inherits the position bias. Returns horizontal meters flown."""
        true_target = self.target.copy()
        true_target[:2] -= self.bias
        delta = true_target - self.true_pos
        dist = np.linalg.norm(delta)
        step_len = min(dist, self.cfg.cruise_speed * dt)
        if dist < 1e-6:
            return 0.0
        move = delta / dist * step_len
        self.true_pos += move
        if np.hypot(move[0], move[1]) > 0.1:
            self.yaw = float(np.arctan2(move[1], move[0]))
        return float(np.hypot(move[0], move[1]))

    def apply_fix(self, bias_xy, err):
        self.bias = np.asarray(bias_xy, dtype=float)
        self.err = float(err)

    def step(self, dt, t):
        c = self.cfg
        if self.state == "charging":
            self.charge_left -= dt
            if self.charge_left <= 0:
                self.state, self.battery_s, self.anchors_left = "landed", c.battery_s, c.anchors_per_drone
            return
        if self.state != "flying" or self.target is None:
            return

        flown = self._move(dt)

        # Dead-reckoning drift: error grows with distance flown, bias wanders.
        self._drift_dir += self.rng.normal(0, 0.15)
        self.err += c.drift_per_m * flown
        self.bias += 0.7 * c.drift_per_m * flown * np.array([np.cos(self._drift_dir), np.sin(self._drift_dir)])

        self.battery_s -= dt
        self.trail.append(tuple(self.true_pos[:2]))
        if len(self.trail) > 400:
            self.trail.pop(0)

        if self.true_pos[2] <= self.land_eps and self.target[2] <= 0.05:
            self.true_pos[2] = 0.0
            self.state = "landed"

        if self.sensors is not None and self.state == "flying":
            self._pending.extend(self.sensors.sense(self, t))
