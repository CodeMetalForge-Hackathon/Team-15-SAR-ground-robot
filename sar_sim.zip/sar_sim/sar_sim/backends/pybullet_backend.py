"""3D physics backend: Crazyflie 2.x models in PyBullet (gym-pybullet-drones).

Same `Drone` interface, same planner, same belief map -- only the motion comes from
a real quadrotor physics + PID controller instead of the 2D kinematic model.

The 2 km search area is scaled down so Crazyflies fly it in a ~20 m arena:
    horizontal: world_m / XY_SCALE      altitude: search_alt -> PB_SEARCH_ALT

Install (see README):  pybullet, gymnasium, scipy, transforms3d, pillow +
    pip install --no-deps git+https://github.com/utiasDSL/gym-pybullet-drones
"""
import numpy as np

from ..drone import SimDrone

XY_SCALE = 100.0        # 2000 m -> 20 m
PB_SEARCH_ALT = 1.0     # 30 m search altitude -> 1.0 m in the arena
CTRL_HZ = 48


class PyBulletFleet:
    def __init__(self, cfg, gui=True):
        try:
            import pybullet as p
            from gym_pybullet_drones.envs.CtrlAviary import CtrlAviary
            from gym_pybullet_drones.control.DSLPIDControl import DSLPIDControl
            from gym_pybullet_drones.utils.enums import DroneModel, Physics
        except ImportError as e:
            raise SystemExit("3D backend needs pybullet + gym-pybullet-drones. See README "
                             f"'3D backend' section. ({e})")
        self.p, self.cfg = p, cfg
        n = cfg.n_drones
        self.z_scale = PB_SEARCH_ALT / cfg.search_alt
        mx, my = cfg.mothership_xy
        init = np.array([[mx / XY_SCALE + 0.3 * k, my / XY_SCALE, 0.03] for k in range(n)])
        self.env = CtrlAviary(drone_model=DroneModel.CF2X, num_drones=n, initial_xyzs=init,
                              physics=Physics.PYB, pyb_freq=240, ctrl_freq=CTRL_HZ,
                              gui=gui, user_debug_gui=False)
        self.obs, _ = self.env.reset()
        self.ctrl = [DSLPIDControl(drone_model=DroneModel.CF2X) for _ in range(n)]
        self.carrot = init.copy()
        self.gui = gui
        rng = np.random.default_rng(cfg.seed + 1000)
        self.drones = [PyBulletDrone(f"finder{k + 1}", cfg, rng, self, k,
                                     start_xy=(mx + 0.3 * k * XY_SCALE, my)) for k in range(n)]
        self.sim = None
        self._markers = {}
        if gui:
            h = cfg.area_m / 2 / XY_SCALE
            p.resetDebugVisualizerCamera(cameraDistance=h * 2.2, cameraYaw=0, cameraPitch=-65,
                                         cameraTargetPosition=[0, 0, 0],
                                         physicsClientId=self.env.CLIENT)
            # search-area boundary
            corners = [(-h, -h), (h, -h), (h, h), (-h, h), (-h, -h)]
            for a, b in zip(corners, corners[1:]):
                p.addUserDebugLine([*a, 0.01], [*b, 0.01], [1, 1, 1], 2,
                                   physicsClientId=self.env.CLIENT)

    # ------------------------------------------------------------------
    def attach(self, sim):
        """Draw victims / anchors in the 3D view (called by run_sim)."""
        self.sim = sim
        if not self.gui:
            return
        p = self.p
        for v in sim.world.victims:
            vis = p.createVisualShape(p.GEOM_SPHERE, radius=0.12, rgbaColor=[1, 0.2, 0.2, 0.9],
                                      physicsClientId=self.env.CLIENT)
            bid = p.createMultiBody(baseMass=0, baseVisualShapeIndex=vis,
                                    basePosition=[v.x / XY_SCALE, v.y / XY_SCALE, 0.12],
                                    physicsClientId=self.env.CLIENT)
            self._markers[("v", v.vid)] = bid

    def _update_markers(self):
        if not (self.gui and self.sim):
            return
        p = self.p
        for v in self.sim.world.victims:
            if v.found_t is not None and ("vf", v.vid) not in self._markers:
                p.changeVisualShape(self._markers[("v", v.vid)], -1, rgbaColor=[0.2, 1, 0.2, 1],
                                    physicsClientId=self.env.CLIENT)
                self._markers[("vf", v.vid)] = True
        for a in self.sim.anchors[1:]:
            if ("a", a.aid) not in self._markers:
                vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.06, 0.06, 0.06],
                                          rgbaColor=[0, 1, 1, 1], physicsClientId=self.env.CLIENT)
                self._markers[("a", a.aid)] = p.createMultiBody(
                    baseMass=0, baseVisualShapeIndex=vis,
                    basePosition=[a.x / XY_SCALE, a.y / XY_SCALE, 0.06], physicsClientId=self.env.CLIENT)

    def advance(self, dt):
        """Run dt seconds of physics. Each drone's carrot moves toward its (true-frame)
        target at cruise speed; the PID controller tracks the carrot."""
        n_ctrl = max(int(round(dt * CTRL_HZ)), 1)
        ctrl_dt = 1.0 / CTRL_HZ
        v_xy = self.cfg.cruise_speed / XY_SCALE
        v_z = self.cfg.cruise_speed * self.z_scale * 0.5
        action = np.zeros((len(self.drones), 4))
        for _ in range(n_ctrl):
            for k, d in enumerate(self.drones):
                goal = d.pb_goal()
                if goal is not None:
                    delta = goal - self.carrot[k]
                    dxy = np.hypot(delta[0], delta[1])
                    if dxy > 1e-9:
                        self.carrot[k, :2] += delta[:2] / dxy * min(dxy, v_xy * ctrl_dt)
                    self.carrot[k, 2] += np.clip(delta[2], -v_z * ctrl_dt, v_z * ctrl_dt)
                if d.state in ("flying",):
                    action[k], _, _ = self.ctrl[k].computeControlFromState(
                        control_timestep=self.env.CTRL_TIMESTEP, state=self.obs[k],
                        target_pos=self.carrot[k], target_rpy=np.zeros(3))
                else:
                    action[k] = 0.0
            self.obs, *_ = self.env.step(action)
        self._update_markers()

    def world_pos(self, k):
        x, y, z = self.obs[k][0:3]
        return np.array([x * XY_SCALE, y * XY_SCALE, max(z, 0.0) / self.z_scale])

    def close(self):
        self.env.close()


class PyBulletDrone(SimDrone):
    """SimDrone whose motion comes from PyBullet physics instead of kinematics.
    Drift / UWB fixes / battery / sensing logic is inherited unchanged."""
    land_eps = 2.0   # world meters (~0.07 m in the arena)

    def __init__(self, drone_id, cfg, rng, fleet, k, start_xy):
        super().__init__(drone_id, cfg, rng, start_xy=start_xy)
        self.fleet, self.k = fleet, k
        self.true_pos = fleet.world_pos(k)

    def pb_goal(self):
        if self.target is None or self.state != "flying":
            return None
        tx, ty = self.target[0] - self.bias[0], self.target[1] - self.bias[1]
        return np.array([tx / XY_SCALE, ty / XY_SCALE, max(self.target[2] * self.fleet.z_scale, 0.03)])

    def _move(self, dt):
        if self.k == 0:                       # first drone steps the shared physics world
            self.fleet.advance(dt)
        prev = self.true_pos.copy()
        self.true_pos = self.fleet.world_pos(self.k)
        mv = self.true_pos - prev
        if np.hypot(mv[0], mv[1]) > 0.1:
            self.yaw = float(np.arctan2(mv[1], mv[0]))
        return float(np.hypot(mv[0], mv[1]))

    def step(self, dt, t):
        # Keep physics running even if drone 0 is charging/landed.
        if self.k == 0 and (self.state != "flying" or self.target is None):
            self.fleet.advance(dt)
            self.true_pos = self.fleet.world_pos(self.k)
        super().step(dt, t)
        if self.state != "flying":
            self.true_pos = self.fleet.world_pos(self.k)
