"""Ground truth: the search area and the victims. Drones never read this directly;
they only see it through simulated sensors."""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class Victim:
    vid: int
    x: float
    y: float
    has_phone: bool          # phone broadcasting BLE / Wi-Fi
    has_wearable: bool       # watch / ESP32 beacon reporting heart rate
    warm: bool               # visible to thermal (False = e.g. under heavy cover)
    injured: bool
    hr_bpm: int
    found_t: float = None    # time confirmed by CV
    found_by: str = None


@dataclass
class World:
    cfg: object
    rng: np.random.Generator
    victims: list = field(default_factory=list)

    @property
    def half(self):
        return self.cfg.area_m / 2

    def spawn_victims(self):
        c, r = self.cfg, self.rng
        self.victims = []
        for i in range(c.n_victims):
            if c.prior_hotspot:
                hx, hy, s = c.prior_hotspot
                x, y = r.normal(hx, s), r.normal(hy, s)
            else:
                # keep victims away from the mothership so the search is non-trivial
                while True:
                    x, y = r.uniform(-self.half * 0.9, self.half * 0.9, 2)
                    if np.hypot(x, y) > 300:
                        break
            x = float(np.clip(x, -self.half + 1, self.half - 1))
            y = float(np.clip(y, -self.half + 1, self.half - 1))
            injured = bool(r.random() < 0.5)
            self.victims.append(Victim(
                vid=i, x=x, y=y,
                has_phone=bool(r.random() < c.p_phone_on),
                has_wearable=bool(r.random() < 0.4),
                warm=bool(r.random() < 0.9),
                injured=injured,
                hr_bpm=int(r.integers(105, 135) if injured else r.integers(65, 95)),
            ))
        return self.victims

    def in_bounds(self, x, y):
        return -self.half <= x <= self.half and -self.half <= y <= self.half
