"""Layered occupancy grid = the shared state everyone reads/writes.

Layers (each ny x nx):
  logodds   - P(victim in cell) as log-odds (Bayesian updates from all sensors)
  coverage  - how many times a cell has been inside a thermal footprint
  last_seen - sim time the cell was last observed
  thermal   - count of thermal hits
  rf        - accumulated BLE/Wi-Fi evidence
"""
import numpy as np


def _logit(p):
    return np.log(p / (1 - p))


class BeliefMap:
    def __init__(self, cfg):
        self.cfg = cfg
        self.n = int(round(cfg.area_m / cfg.cell_m))
        self.half = cfg.area_m / 2
        c = (np.arange(self.n) + 0.5) * cfg.cell_m - self.half
        self.xc, self.yc = np.meshgrid(c, c)      # cell centers, [row=y, col=x]
        p0 = max(cfg.n_victims, 1) / self.n ** 2
        self.logodds = np.full((self.n, self.n), _logit(p0))
        if cfg.prior_hotspot:
            hx, hy, s = cfg.prior_hotspot
            g = np.exp(-((self.xc - hx) ** 2 + (self.yc - hy) ** 2) / (2 * s ** 2))
            self.logodds += 3.0 * g
        self.coverage = np.zeros((self.n, self.n))
        self.last_seen = np.full((self.n, self.n), -1.0)
        self.thermal = np.zeros((self.n, self.n))
        self.rf = np.zeros((self.n, self.n))
        # RF (BLE/Wi-Fi) evidence kept in its own log-odds layer and capped:
        # RF *guides* the search, thermal/CV *confirm*. Stops RSSI rings alone
        # from spawning confirm tasks.
        self.rf_lo = np.zeros((self.n, self.n))
        self.rf_cap = _logit(0.2) - _logit(p0)
        self.found = []          # list of (x, y, info)
        self.rf_by_id, self.rf_count, self.explained_ids = {}, {}, set()

    # ---------- helpers ----------
    @property
    def prob(self):
        lo = self.logodds + np.clip(self.rf_lo, -2.0, self.rf_cap)
        return 1 / (1 + np.exp(-lo))

    def cell_of(self, x, y):
        i = int(np.clip((x + self.half) // self.cfg.cell_m, 0, self.n - 1))
        j = int(np.clip((y + self.half) // self.cfg.cell_m, 0, self.n - 1))
        return j, i

    def center_of(self, j, i):
        return float(self.xc[j, i]), float(self.yc[j, i])

    def _window(self, x, y, r):
        cm = self.cfg.cell_m
        i0 = int(np.clip((x - r + self.half) // cm, 0, self.n - 1))
        i1 = int(np.clip((x + r + self.half) // cm, 0, self.n - 1)) + 1
        j0 = int(np.clip((y - r + self.half) // cm, 0, self.n - 1))
        j1 = int(np.clip((y + r + self.half) // cm, 0, self.n - 1)) + 1
        sl = (slice(j0, j1), slice(i0, i1))
        d = np.hypot(self.xc[sl] - x, self.yc[sl] - y)
        return sl, d

    # ---------- sensor updates ----------
    def observe_footprint(self, x, y, z, err, t, step_len, hit_xy=()):
        """Negative evidence: thermal looked here and (mostly) saw nothing."""
        c = self.cfg
        r = c.thermal_radius * (z / c.search_alt)
        if r <= 1:
            return
        sl, d = self._window(x, y, r)
        mask = d <= r
        self.coverage[sl][mask] += 1
        self.last_seen[sl][mask] = t
        # Looks while moving are correlated; weight by fraction of new ground covered.
        k = float(np.clip(step_len / (2 * r), 0.15, 1.0))
        # Position error blurs where we actually looked -> weaker update when lost.
        k *= float(np.clip(r / (r + err), 0.2, 1.0))
        lr = (1 - c.thermal_pd) / (1 - c.thermal_fa_per_cell)
        upd = np.where(mask, k * np.log(lr), 0.0)
        for hx, hy in hit_xy:            # don't penalize where we just got a hit
            upd[np.hypot(self.xc[sl] - hx, self.yc[sl] - hy) < 2 * c.cell_m] = 0.0
        self.logodds[sl] += upd

    def thermal_hit(self, x, y, err, score=0.8):
        c = self.cfg
        s = max(err, c.cell_m / 2)
        sl, d = self._window(x, y, 2.5 * s)
        g = np.exp(-d ** 2 / (2 * s ** 2)) * (c.cell_m ** 2 / (2 * np.pi * s ** 2))
        # Detector confidence scales the evidence (blob shape/temperature filter).
        lr = 1 + (c.thermal_pd / c.thermal_fa_per_cell - 1) * score ** 3
        self.logodds[sl] += np.log1p((lr - 1) * np.clip(g, 0, 1))
        self.thermal[sl] += g

    def rf_hit(self, x, y, z, err, rssi, ble_id=None):
        """RSSI -> range ring around the drone. Evidence is tracked per device ID so it
        can be removed ("explained away") once that device's owner is confirmed."""
        c = self.cfg
        if ble_id in self.explained_ids:
            return
        r = 10 ** ((c.ble_tx_dbm - rssi) / (10 * c.ble_path_n))
        rh = np.sqrt(max(r ** 2 - z ** 2, 0.0))
        sr = 0.35 * rh + err + c.cell_m
        sl, d = self._window(x, y, min(rh + 3 * sr, c.ble_range * 2))
        g = np.exp(-(d - rh) ** 2 / (2 * sr ** 2))
        contrib = 0.3 * np.log(0.85 + 4.0 * g)
        self.rf_lo[sl] += contrib
        self.rf[sl] += g
        if ble_id is not None:
            acc = self.rf_by_id.setdefault(ble_id, np.zeros_like(self.rf_lo))
            acc[sl] += contrib
            self.rf_count[ble_id] = self.rf_count.get(ble_id, 0) + 1
            if self.rf_count[ble_id] >= 4:
                self._try_explain(ble_id)

    def _id_location(self, ble_id):
        acc = self.rf_by_id[ble_id]
        j, i = np.unravel_index(np.argmax(acc), acc.shape)
        return self.center_of(j, i)

    def _try_explain(self, ble_id):
        if ble_id in self.explained_ids or ble_id not in self.rf_by_id:
            return
        x, y = self._id_location(ble_id)
        for fx, fy, info in self.found:
            if np.hypot(x - fx, y - fy) < 150 + info.get("err", 0):
                self.rf_lo -= self.rf_by_id.pop(ble_id)
                self.explained_ids.add(ble_id)
                return

    def mark_found(self, x, y, info):
        r = 80 + info.get("err", 0)
        sl, d = self._window(x, y, r)
        self.logodds[sl][d <= r] = -8.0
        self.found.append((x, y, info))
        for bid in list(self.rf_by_id):    # phones belonging to this victim are explained
            if self.rf_count.get(bid, 0) >= 2:
                self._try_explain(bid)

    def clamp(self):
        np.clip(self.logodds, -12, 8, out=self.logodds)

    # ---------- planning helpers ----------
    def value_map(self, radius):
        """Sum of probability inside a footprint around every cell (box filter)."""
        p = self.prob
        k = max(int(radius // self.cfg.cell_m), 1)
        P = np.pad(p, k, mode="constant")
        S = P.cumsum(0).cumsum(1)
        S = np.pad(S, ((1, 0), (1, 0)))
        w = 2 * k + 1
        return S[w:, w:] - S[:-w, w:] - S[w:, :-w] + S[:-w, :-w]

    def coverage_pct(self):
        return 100.0 * float((self.coverage > 0).mean())
