"""Multi-drone task allocation.

Each replan:
  1. Battery check -> send drones home with a reserve.
  2. High-probability cells become CONFIRM tasks; nearest free drone drops low for CV.
  3. Everyone else SEARCHes: pick the cell maximizing (probability mass in footprint)
     / (1 + distance/d0), spread out from other drones' targets.

This is a greedy information-gain planner. The team's MCTS / A* planner can replace
`_pick_search_target` without touching anything else.
"""
import numpy as np


class Planner:
    def __init__(self, cfg, belief):
        self.cfg, self.belief = cfg, belief
        self.confirms = {}       # cid -> dict(x, y, drone, t0)
        self._next_cid = 0
        self.events = []

    def log(self, t, msg):
        self.events.append((t, msg))

    # ------------------------------------------------------------------
    def update(self, drones, t):
        c = self.cfg
        self._refresh_confirms(drones, t)

        claimed = []
        for d in drones:
            if d.state == "charging":
                continue
            x, y, z, _, err = d.get_pose()

            # 1. battery / return-to-mothership
            if d.state == "flying":
                t_home = np.hypot(x, y) / c.cruise_speed + 20
                if d.task != "return" and d.battery_s < t_home + c.battery_reserve_s:
                    self._release(d)
                    d.task = "return"
                    d.goto(0.0, 0.0, c.search_alt)
                    self.log(t, f"{d.drone_id} low battery -> returning")
                if d.task == "return":
                    if np.hypot(x, y) < 8:
                        d.land()
                    continue
            if d.state == "landed":
                if d.battery_s < c.battery_s * 0.95:
                    continue
                d.takeoff(c.search_alt)
                d.task = "search"

            # 2. confirm tasks
            mine = [cid for cid, cf in self.confirms.items() if cf["drone"] == d.drone_id]
            if mine:
                cf = self.confirms[mine[0]]
                d.task = "confirm"
                if "arrived" not in cf and np.hypot(cf["x"] - x, cf["y"] - y) < 20:
                    cf["arrived"] = t
                if "arrived" in cf:   # small orbit to beat position error
                    a = 0.6 * (t - cf["arrived"])
                    rr = min(10 + err, 30)
                    d.goto(cf["x"] + rr * np.cos(a), cf["y"] + rr * np.sin(a), c.confirm_alt)
                else:
                    d.goto(cf["x"], cf["y"], c.confirm_alt)
                claimed.append((cf["x"], cf["y"]))
                continue

            # 3. search
            d.task = "search"
            tx, ty = self._pick_search_target(x, y, claimed, drones, d)
            claimed.append((tx, ty))
            d.goto(tx, ty, c.search_alt)

    # ------------------------------------------------------------------
    def _pick_search_target(self, x, y, claimed, drones, me):
        c, b = self.cfg, self.belief
        V = b.value_map(c.thermal_radius).copy()
        dist = np.hypot(b.xc - x, b.yc - y)
        score = V / (1.0 + dist / 200.0)
        # Sector split: each drone owns an angular slice around the mothership.
        ids = sorted(d.drone_id for d in drones)
        k, n = ids.index(me.drone_id), len(ids)
        ang = np.mod(np.arctan2(b.yc, b.xc), 2 * np.pi)
        own = (ang >= 2 * np.pi * k / n) & (ang < 2 * np.pi * (k + 1) / n)
        score = np.where(own, score, 0.35 * score)
        sep = 3 * c.thermal_radius
        for cx, cy in claimed:
            score[np.hypot(b.xc - cx, b.yc - cy) < sep * 2] *= 0.05
        for o in drones:
            if o is me or o.state != "flying":
                continue
            ox, oy, *_ = o.get_pose()
            score[np.hypot(b.xc - ox, b.yc - oy) < sep] *= 0.3
        # Must be able to get there and back
        t_needed = (dist + np.hypot(b.xc, b.yc)) / c.cruise_speed + c.battery_reserve_s + 30
        score[t_needed > me.battery_s] = 0
        score[dist < c.thermal_radius] *= 0.2   # don't target where we already are

        # Path-integrated value: prefer long straight legs over unsearched / promising
        # ground (gives lawnmower-like efficiency, but bends toward RF/thermal leads).
        flat = np.argsort(score.ravel())[-150:]
        flat = flat[score.ravel()[flat] > 0]
        if flat.size == 0:
            j, i = np.unravel_index(np.argmax(score), score.shape)
            return b.center_of(j, i)
        tx, ty = b.xc.ravel()[flat], b.yc.ravel()[flat]
        u = np.linspace(0, 1, 25)[None, :]
        px, py = x + (tx[:, None] - x) * u, y + (ty[:, None] - y) * u
        ii = np.clip(((px + b.half) // c.cell_m).astype(int), 0, b.n - 1)
        jj = np.clip(((py + b.half) // c.cell_m).astype(int), 0, b.n - 1)
        Vown = V * np.where(own, 1.0, 0.35)
        gain = Vown[jj, ii].mean(1) * np.hypot(tx - x, ty - y)      # ~value swept
        util = gain / (np.hypot(tx - x, ty - y) / c.cruise_speed + 20) + 0.5 * score.ravel()[flat]
        k = int(np.argmax(util))
        return float(tx[k]), float(ty[k])

    def _release(self, d):
        for cf in self.confirms.values():
            if cf["drone"] == d.drone_id:
                cf["drone"] = None
                cf.pop("arrived", None)

    def _refresh_confirms(self, drones, t):
        c, b = self.cfg, self.belief
        p = b.prob

        # update / retire existing confirm tasks
        for cid in list(self.confirms):
            cf = self.confirms[cid]
            sl, d = b._window(cf["x"], cf["y"], 60)
            local = np.where(d <= 60, p[sl], 0)
            pmax = float(local.max()) if local.size else 0.0
            if any(np.hypot(fx - cf["x"], fy - cf["y"]) < 100 for fx, fy, _ in b.found):
                del self.confirms[cid]
                continue
            if pmax < c.confirm_threshold * 0.3:
                self.log(t, f"candidate @({cf['x']:.0f},{cf['y']:.0f}) cleared (false alarm)")
                del self.confirms[cid]
                continue
            if cf.get("arrived") is not None and t - cf["arrived"] > 40:
                b.logodds[sl][d <= 60] -= 3.0
                self.log(t, f"candidate @({cf['x']:.0f},{cf['y']:.0f}) timed out")
                del self.confirms[cid]
                continue
            jj, ii = np.unravel_index(np.argmax(local), local.shape)
            cf["x"], cf["y"] = float(b.xc[sl][jj, ii]), float(b.yc[sl][jj, ii])

        # new candidates: local maxima above threshold
        flat = np.flatnonzero(p > c.confirm_threshold)
        flat = flat[np.argsort(-p.ravel()[flat])][:40]
        for j, i in zip(*np.unravel_index(flat, p.shape)):
            x, y = b.center_of(j, i)
            if any(np.hypot(cf["x"] - x, cf["y"] - y) < 80 for cf in self.confirms.values()):
                continue
            if any(np.hypot(fx - x, fy - y) < 100 for fx, fy, _ in b.found):
                continue
            cid = self._next_cid
            self._next_cid += 1
            self.confirms[cid] = dict(x=x, y=y, drone=None, t0=t, p=float(p[j, i]))
            self.log(t, f"candidate #{cid} @({x:.0f},{y:.0f}) p={p[j, i]:.2f}")

        # assign unowned confirms to nearest free drone
        busy = {cf["drone"] for cf in self.confirms.values() if cf["drone"]}
        for cid, cf in self.confirms.items():
            if cf["drone"]:
                continue
            best, bd = None, 1e18
            for d in drones:
                if d.state != "flying" or d.task == "return" or d.drone_id in busy:
                    continue
                x, y, *_ = d.get_pose()
                dist = np.hypot(cf["x"] - x, cf["y"] - y)
                if d.battery_s < (dist + np.hypot(cf["x"], cf["y"])) / c.cruise_speed + c.battery_reserve_s + 60:
                    continue
                if dist < bd:
                    best, bd = d, dist
            if best:
                cf["drone"], cf["t0"] = best.drone_id, t
                busy.add(best.drone_id)
                self.log(t, f"{best.drone_id} -> confirm #{cid}")


class LawnmowerPlanner(Planner):
    """Baseline for comparison: each drone sweeps its own vertical strip back and
    forth (boustrophedon). Same battery + confirm logic, no belief-driven search."""

    def __init__(self, cfg, belief):
        super().__init__(cfg, belief)
        self.paths, self.idx = {}, {}

    def _path(self, k, n):
        c = self.cfg
        h = c.area_m / 2
        lane = 1.8 * c.thermal_radius
        x0, x1 = -h + k * c.area_m / n, -h + (k + 1) * c.area_m / n
        xs = np.arange(x0 + lane / 2, x1, lane)
        pts = []
        for m, x in enumerate(xs):
            ys = (-h + lane / 2, h - lane / 2)
            if m % 2:
                ys = ys[::-1]
            pts += [(x, ys[0]), (x, ys[1])]
        return pts

    def _pick_search_target(self, x, y, claimed, drones, me):
        ids = sorted(d.drone_id for d in drones)
        if me.drone_id not in self.paths:
            self.paths[me.drone_id] = self._path(ids.index(me.drone_id), len(ids))
            self.idx[me.drone_id] = 0
        path, i = self.paths[me.drone_id], self.idx[me.drone_id]
        while i < len(path) - 1 and np.hypot(path[i][0] - x, path[i][1] - y) < 15:
            i += 1
        self.idx[me.drone_id] = i
        return path[i]
