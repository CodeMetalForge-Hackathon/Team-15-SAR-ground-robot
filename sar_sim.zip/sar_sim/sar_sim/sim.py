"""Simulation loop: drones + sensors + belief + planner + GPS-denied positioning."""
import json
import numpy as np

from .config import SimConfig
from .world import World
from .belief import BeliefMap
from .sensors import SensorSuite
from .drone import SimDrone
from .planner import Planner


class Anchor:
    """ESP32 breadcrumb node (UWB anchor + mesh relay). Mothership is anchor 0."""
    def __init__(self, aid, x, y, bias, err, owner):
        self.aid, self.x, self.y = aid, x, y      # true placement
        self.bias, self.err, self.owner = np.asarray(bias, float), err, owner


class Simulation:
    def __init__(self, cfg: SimConfig = None, drones=None, log_path=None):
        self.cfg = cfg or SimConfig()
        c = self.cfg
        self.rng = np.random.default_rng(c.seed)
        self.world = World(c, self.rng)
        self.world.spawn_victims()
        self.belief = BeliefMap(c)
        self.sensors = SensorSuite(c, self.world, self.rng)
        mx, my = c.mothership_xy
        self.anchors = [Anchor(0, mx, my, (0, 0), 0.0, "mothership")]
        if drones is None:
            drones = [SimDrone(f"finder{i + 1}", c, self.rng, start_xy=(mx + 3 * i, my)) for i in range(c.n_drones)]
        self.drones = drones
        for d in self.drones:
            d.sensors = self.sensors
        self.planner = Planner(c, self.belief)
        self.t = 0.0
        self._last_plan = -1e9
        self.n_packets = 0
        self.log_f = open(log_path, "w") if log_path else None

    # ------------------------------------------------------------------
    @property
    def done(self):
        return all(v.found_t is not None for v in self.world.victims) or self.t >= self.cfg.max_time_s

    def step(self):
        c, b = self.cfg, self.belief
        arrived = any(getattr(d, "task", "") == "search" and d.target is not None and
                      np.hypot(*(d.est_pos[:2] - d.target[:2])) < 10 for d in self.drones)
        if arrived or self.t - self._last_plan >= c.replan_every_s:
            self.planner.update(self.drones, self.t)
            self._last_plan = self.t

        for d in self.drones:
            prev = np.array(d.true_pos[:2])
            d.step(c.dt, self.t)
            step_len = float(np.hypot(*(np.array(d.true_pos[:2]) - prev)))

            if getattr(d, "state", "flying") == "flying":
                self._positioning(d)
                self._maybe_drop_anchor(d)

            pkts = d.get_detections()
            hits = []
            for p in pkts:
                self._ingest(p, d)
                if p["type"] == "thermal":
                    hits.append((p["x"], p["y"]))
            if getattr(d, "state", "flying") == "flying":
                x, y, z, _, err = d.get_pose()
                b.observe_footprint(x, y, z, err, self.t, max(step_len, 0.5), hits)

            # landed at mothership after a return -> recharge
            if getattr(d, "task", None) == "return" and d.state == "landed":
                d.state, d.charge_left, d.task = "charging", c.recharge_s, "idle"
                d.apply_fix((0, 0), 0.5)
                d.trail.clear()
                self.planner.log(self.t, f"{d.drone_id} recharging")

        b.clamp()
        self.t += c.dt

    # ------------------------------------------------------------------
    def _positioning(self, d):
        """UWB fix if any anchor is in range (true geometry), else keep dead-reckoning."""
        c = self.cfg
        tx, ty = d.true_pos[0], d.true_pos[1]
        best = None
        for a in self.anchors:
            if np.hypot(a.x - tx, a.y - ty) <= c.uwb_range and (best is None or a.err < best.err):
                best = a
        if best is not None:
            new_err = best.err + c.uwb_err
            if new_err < d.err:
                d.apply_fix(best.bias + self.rng.normal(0, c.uwb_err / 2, 2), new_err)

    def _maybe_drop_anchor(self, d):
        c = self.cfg
        if getattr(d, "anchors_left", 0) <= 0 or getattr(d, "task", "") == "return":
            return
        tx, ty = d.true_pos[0], d.true_pos[1]
        if min(np.hypot(a.x - tx, a.y - ty) for a in self.anchors) > c.anchor_spacing:
            self.anchors.append(Anchor(len(self.anchors), tx, ty, d.bias.copy(), d.err, d.drone_id))
            d.anchors_left -= 1
            ex, ey, *_ = d.get_pose()
            self.planner.log(self.t, f"{d.drone_id} dropped anchor #{len(self.anchors) - 1} @({ex:.0f},{ey:.0f})")

    def _ingest(self, p, d):
        b = self.belief
        self.n_packets += 1
        if self.log_f:
            self.log_f.write(json.dumps(p) + "\n")
        if p["type"] == "thermal":
            if not self._explained_thermal(p):
                b.thermal_hit(p["x"], p["y"], p["err"], p.get("score", 0.8))
        elif p["type"] == "ble":
            b.rf_hit(p["x"], p["y"], d.get_pose()[2], p["err"], p["rssi"], p.get("id"))
        elif p["type"] == "rgb" and p["score"] >= 0.8:
            v = self.world.victims[p["victim_truth_id"]]   # sim-only: for scoring
            if v.found_t is None:
                v.found_t, v.found_by = self.t, p["source_id"]
                info = dict(vid=v.vid, by=p["source_id"], t=self.t, injured=p["injured"], err=p["err"],
                            hr=v.hr_bpm if v.has_wearable else None)
                b.mark_found(p["x"], p["y"], info)
                status = "INJURED" if p["injured"] else "ok"
                hr = f", HR {v.hr_bpm}" if v.has_wearable else ""
                self.planner.log(self.t, f"*** VICTIM {v.vid} CONFIRMED by {p['source_id']} "
                                         f"@({p['x']:.0f},{p['y']:.0f}) [{status}{hr}]")

    # --- data association: signals already explained by a confirmed victim ---
    def _explained_thermal(self, p):
        return any(np.hypot(p["x"] - fx, p["y"] - fy) < 80 + p["err"] + inf["err"]
                   for fx, fy, inf in self.belief.found)

    # ------------------------------------------------------------------
    def summary(self):
        found = [v for v in self.world.victims if v.found_t is not None]
        return dict(t=self.t, found=len(found), total=len(self.world.victims),
                    find_times=[round(v.found_t) for v in found],
                    coverage_pct=round(self.belief.coverage_pct(), 1),
                    anchors=len(self.anchors) - 1, packets=self.n_packets)

    def close(self):
        if self.log_f:
            self.log_f.close()
