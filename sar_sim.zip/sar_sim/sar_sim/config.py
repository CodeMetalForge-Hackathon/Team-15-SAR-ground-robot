"""All tunable numbers in one place. Units: meters, seconds, dBm."""
from dataclasses import dataclass


@dataclass
class SimConfig:
    # --- World / grid (matches the team mapping plan: 2 km x 2 km, 20 m cells) ---
    area_m: float = 2000.0          # square search area side length
    cell_m: float = 20.0            # grid cell size -> 100 x 100 grid
    mothership_xy: tuple = (0.0, 0.0)  # origin (0,0); area spans [-area/2, +area/2]
    seed: int = 7

    # --- Mission ---
    n_drones: int = 3
    n_victims: int = 3
    dt: float = 1.0                 # sim step (s)
    max_time_s: float = 3600.0
    replan_every_s: float = 5.0

    # --- Drone ---
    cruise_speed: float = 12.0      # m/s
    search_alt: float = 30.0        # m
    confirm_alt: float = 10.0       # m (fly low to confirm with camera)
    battery_s: float = 900.0        # endurance (s)
    battery_reserve_s: float = 60.0
    recharge_s: float = 120.0       # swap/charge time at the mothership

    # --- GPS-denied positioning (dead reckoning + UWB anchors) ---
    drift_per_m: float = 0.03       # position error growth per meter flown w/o a fix
    uwb_range: float = 250.0        # UWB anchor range (m)
    uwb_err: float = 2.0            # position error when an anchor is in range (m)
    anchors_per_drone: int = 3      # ESP32 breadcrumb nodes each drone can drop
    anchor_spacing: float = 400.0   # drop a new anchor when farther than this from all anchors

    # --- Thermal camera ---
    thermal_radius: float = 40.0    # ground footprint radius at search_alt
    thermal_pd: float = 0.80        # P(detect warm body in footprint)
    thermal_fa_per_cell: float = 0.0005  # false alarm rate per cell per look (rocks, animals)

    # --- BLE / Wi-Fi phone scan (ESP32) ---
    ble_range: float = 120.0
    ble_tx_dbm: float = -59.0       # RSSI at 1 m
    ble_path_n: float = 2.2         # path-loss exponent
    ble_sigma_db: float = 4.0       # RSSI noise
    p_phone_on: float = 0.6         # fraction of victims with a phone broadcasting

    # --- RGB camera / CV confirm ---
    cv_radius: float = 25.0         # must be this close (horizontal) to confirm
    cv_p: float = 0.7               # P(confirm per step when in range)

    # --- Belief / planning ---
    confirm_threshold: float = 0.5   # cell probability that triggers a confirm task
    prior_hotspot: tuple = None      # optional (x, y, sigma_m) last-known-position prior
