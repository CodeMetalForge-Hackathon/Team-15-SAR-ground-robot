"""Live matplotlib view of the simulation.

Keys:  space = pause   + / - = speed   t = show/hide ground truth
       c = probability <-> coverage layer   q = quit
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import Circle

COLORS = ["#4FC3F7", "#FFB74D", "#81C784", "#F06292", "#BA68C8", "#FFF176"]


class LiveView:
    def __init__(self, sim, steps_per_frame=5, show_truth=True):
        self.sim, self.spf, self.show_truth = sim, steps_per_frame, show_truth
        self.paused, self.layer = False, "prob"
        c = sim.cfg
        h = c.area_m / 2
        self.ext = [-h, h, -h, h]

        plt.style.use("dark_background")
        self.fig = plt.figure(figsize=(14, 8))
        self.fig.canvas.manager.set_window_title("SAR multi-drone simulation")
        self.ax = self.fig.add_axes([0.05, 0.07, 0.52, 0.86])
        self.cax = self.fig.add_axes([0.575, 0.07, 0.012, 0.86])
        self.info = self.fig.add_axes([0.64, 0.07, 0.35, 0.86])
        self.info.axis("off")

        self.img = self.ax.imshow(self._layer(), origin="lower", extent=self.ext,
                                  cmap="inferno", vmin=-4.5, vmax=0, interpolation="nearest")
        cb = self.fig.colorbar(self.img, cax=self.cax)
        cb.set_label("log10 P(victim in cell)")
        self.cb = cb
        self.ax.set_xlim(-h, h)
        self.ax.set_ylim(-h, h)
        self.ax.set_xlabel("x (m from mothership)")
        self.ax.set_ylabel("y (m)")
        self.ax.set_title("Belief map — GPS-denied, origin = mothership")
        mx, my = c.mothership_xy
        self.ax.plot([mx], [my], "s", color="white", ms=11, mec="black", zorder=6)
        self.ax.annotate("MOTHERSHIP", (mx, my), xytext=(8, -14), textcoords="offset points",
                         color="white", fontsize=8)

        self.anchor_pts, = self.ax.plot([], [], "^", color="cyan", ms=7, mec="black", zorder=5,
                                        label="ESP32 anchor")
        self.victim_pts, = self.ax.plot([], [], "P", color="white", ms=9, alpha=0.55, zorder=4,
                                        label="victim (truth)")
        self.found_pts, = self.ax.plot([], [], "*", color="lime", ms=18, mec="black", zorder=7,
                                       label="confirmed")
        self.cand_pts, = self.ax.plot([], [], "D", mfc="none", mec="yellow", ms=12, mew=2, zorder=6,
                                      label="candidate")
        self.found_txt = []

        self.d_art = []
        for k, d in enumerate(sim.drones):
            col = COLORS[k % len(COLORS)]
            trail, = self.ax.plot([], [], "-", color=col, lw=1, alpha=0.6)
            tgt, = self.ax.plot([], [], "--", color=col, lw=0.8, alpha=0.7)
            body, = self.ax.plot([], [], "o", color=col, ms=9, mec="white", zorder=8, label=d.drone_id)
            true, = self.ax.plot([], [], "x", color=col, ms=6, zorder=8)
            fp = Circle((0, 0), 1, fill=False, ec=col, lw=1.2)
            er = Circle((0, 0), 1, fill=False, ec=col, lw=0.8, ls=":")
            self.ax.add_patch(fp)
            self.ax.add_patch(er)
            lbl = self.ax.text(0, 0, d.drone_id, color=col, fontsize=8, zorder=9)
            self.d_art.append((trail, tgt, body, true, fp, er, lbl))
        self.ax.legend(loc="upper right", fontsize=7, framealpha=0.4, ncol=2)

        self.txt = self.info.text(0, 1, "", va="top", ha="left", family="monospace", fontsize=9)
        self.fig.canvas.mpl_connect("key_press_event", self._key)

    # ------------------------------------------------------------------
    def _layer(self):
        b = self.sim.belief
        if self.layer == "prob":
            return np.log10(np.clip(b.prob, 1e-6, 1))
        return np.clip(b.coverage / 10.0, 0, 1) * 4.5 - 4.5

    def _key(self, e):
        if e.key == " ":
            self.paused = not self.paused
        elif e.key in ("+", "="):
            self.spf = min(self.spf * 2, 200)
        elif e.key == "-":
            self.spf = max(self.spf // 2, 1)
        elif e.key == "t":
            self.show_truth = not self.show_truth
        elif e.key == "c":
            self.layer = "coverage" if self.layer == "prob" else "prob"
            cov = self.layer == "coverage"
            self.ax.set_title("Coverage (times observed)" if cov
                              else "Belief map — GPS-denied, origin = mothership")
            self.cb.set_label("times observed (0 → 10+)" if cov else "log10 P(victim in cell)")
        elif e.key == "q":
            plt.close(self.fig)

    def _frame(self, _):
        s = self.sim
        if not self.paused and not s.done:
            for _ in range(self.spf):
                if s.done:
                    break
                s.step()
        self.draw()
        return []

    def draw(self):
        s, c, b = self.sim, self.sim.cfg, self.sim.belief
        self.img.set_data(self._layer())

        self.anchor_pts.set_data([a.x + a.bias[0] for a in s.anchors[1:]],
                                 [a.y + a.bias[1] for a in s.anchors[1:]])
        hidden = [v for v in s.world.victims if v.found_t is None]
        if self.show_truth:
            self.victim_pts.set_data([v.x for v in hidden], [v.y for v in hidden])
        else:
            self.victim_pts.set_data([], [])
        self.found_pts.set_data([f[0] for f in b.found], [f[1] for f in b.found])
        for t in self.found_txt:
            t.remove()
        self.found_txt = []
        for fx, fy, inf in b.found:
            tag = "INJURED" if inf["injured"] else "ok"
            if inf.get("hr"):
                tag += f" HR{inf['hr']}"
            self.found_txt.append(self.ax.text(fx + 25, fy + 25, f"V{inf['vid']} {tag}",
                                               color="lime", fontsize=8, zorder=9))
        cf = list(s.planner.confirms.values())
        self.cand_pts.set_data([q["x"] for q in cf], [q["y"] for q in cf])

        for d, (trail, tgt, body, true, fp, er, lbl) in zip(s.drones, self.d_art):
            x, y, z, _, err = d.get_pose()
            vis = d.state != "charging"
            body.set_data(([x], [y]) if vis else ([], []))
            if d.trail:
                tr = np.array(d.trail)
                trail.set_data(tr[:, 0] + d.bias[0], tr[:, 1] + d.bias[1])
            else:
                trail.set_data([], [])
            if self.show_truth and vis:
                true.set_data([d.true_pos[0]], [d.true_pos[1]])
            else:
                true.set_data([], [])
            if d.target is not None and d.state == "flying":
                tgt.set_data([x, d.target[0]], [y, d.target[1]])
            else:
                tgt.set_data([], [])
            fp.center, er.center = (x, y), (x, y)
            fp.set_radius(max(c.thermal_radius * z / c.search_alt, 0.1))
            er.set_radius(max(err, 0.1))
            fp.set_visible(vis)
            er.set_visible(vis)
            lbl.set_position((x + 20, y - 45))
            lbl.set_visible(vis)

        # ---- side panel ----
        sm = s.summary()
        m, sec = divmod(int(s.t), 60)
        lines = [f"T+ {m:02d}:{sec:02d}     speed x{self.spf}{'  [PAUSED]' if self.paused else ''}",
                 "",
                 f"Victims confirmed : {sm['found']}/{sm['total']}",
                 f"Area covered      : {sm['coverage_pct']:.1f}%",
                 f"Anchors dropped   : {sm['anchors']}",
                 f"Detections        : {sm['packets']}",
                 "",
                 "DRONE     STATE    TASK     BATT  POS-ERR",
                 "-" * 42]
        for d in s.drones:
            batt = 100 * max(d.battery_s, 0) / c.battery_s
            lines.append(f"{d.drone_id:<9} {d.state:<8} {d.task:<8} {batt:4.0f}%  {d.err:5.1f} m")
        lines += ["", "EVENTS", "-" * 42]
        for t, e in s.planner.events[-16:]:
            mm, ss = divmod(int(t), 60)
            lines.append(f"{mm:02d}:{ss:02d} {e}"[:60])
        if s.done:
            lines += ["", "=== MISSION COMPLETE ===" if sm["found"] == sm["total"] else "=== TIME LIMIT ==="]
        lines += ["", "keys: space pause  +/- speed  t truth  c layer  q quit"]
        self.txt.set_text("\n".join(lines))

    def run(self, save_path=None, frames=None):
        self.anim = FuncAnimation(self.fig, self._frame, interval=50, cache_frame_data=False,
                                  frames=frames)
        if save_path:
            self.anim.save(save_path, fps=20, dpi=80)
        else:
            plt.show()
