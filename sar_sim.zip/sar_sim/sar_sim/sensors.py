"""Simulated sensors. Each returns detection packets in the team data contract:

    {source_id, t, type: thermal|ble|rgb, x, y, err, score, ...extra}

x, y are in the drone's *estimated* frame (relative to the mothership origin), so
dead-reckoning error shows up in the detections exactly as it would on hardware.
"""
import hashlib
import numpy as np


def _rotating_id(vid, t):
    # Phones randomize their BLE MAC every ~15 min; model that so code can't rely on it.
    return hashlib.md5(f"{vid}-{int(t // 900)}".encode()).hexdigest()[:12]


class SensorSuite:
    def __init__(self, cfg, world, rng):
        self.cfg, self.world, self.rng = cfg, world, rng

    def sense(self, drone, t):
        c, r = self.cfg, self.rng
        tx, ty, tz = drone.true_pos
        ex, ey, _ = drone.est_pos
        off_x, off_y = ex - tx, ey - ty      # estimation error carried into reports
        out = []
        base = dict(source_id=drone.drone_id, t=round(t, 2))

        # Thermal footprint scales with altitude
        th_r = c.thermal_radius * (tz / c.search_alt) if tz > 1 else 0.0

        for v in self.world.victims:
            d_h = np.hypot(v.x - tx, v.y - ty)
            d_3d = np.hypot(d_h, tz)

            # --- thermal ---
            if th_r > 0 and v.warm and d_h <= th_r and r.random() < c.thermal_pd:
                out.append({**base, "type": "thermal",
                            "x": v.x + off_x + r.normal(0, 3), "y": v.y + off_y + r.normal(0, 3),
                            "err": drone.err + 3, "score": round(float(r.uniform(0.6, 0.95)), 2),
                            "max_temp_c": round(float(r.uniform(31, 36)), 1)})

            # --- BLE / Wi-Fi RSSI ---
            if v.has_phone and d_3d <= c.ble_range and tz > 0.5:
                rssi = c.ble_tx_dbm - 10 * c.ble_path_n * np.log10(max(d_3d, 1)) + r.normal(0, c.ble_sigma_db)
                pkt = {**base, "type": "ble", "x": ex, "y": ey, "err": drone.err,
                       "id": _rotating_id(v.vid, t), "rssi": round(float(rssi), 1), "score": 0.5}
                if v.has_wearable:
                    pkt["hr_bpm"] = v.hr_bpm
                out.append(pkt)

            # --- RGB / CV confirm (needs to be close) ---
            if d_h <= c.cv_radius and tz > 0.5 and r.random() < c.cv_p:
                out.append({**base, "type": "rgb", "x": v.x + off_x, "y": v.y + off_y,
                            "err": drone.err + 1, "score": round(float(r.uniform(0.8, 0.98)), 2),
                            "injured": v.injured, "victim_truth_id": v.vid})

        # --- thermal false alarms (warm rocks, animals, hot vehicles) ---
        if th_r > 0:
            cells_in_fp = np.pi * th_r ** 2 / c.cell_m ** 2
            for _ in range(r.poisson(c.thermal_fa_per_cell * cells_in_fp)):
                a, rad = r.uniform(0, 2 * np.pi), th_r * np.sqrt(r.random())
                out.append({**base, "type": "thermal",
                            "x": ex + rad * np.cos(a), "y": ey + rad * np.sin(a),
                            "err": drone.err + 3, "score": round(float(r.uniform(0.3, 0.6)), 2),
                            "max_temp_c": round(float(r.uniform(28, 33)), 1)})

        for p in out:
            p["x"], p["y"], p["err"] = round(float(p["x"]), 1), round(float(p["y"]), 1), round(float(p["err"]), 1)
        return out
